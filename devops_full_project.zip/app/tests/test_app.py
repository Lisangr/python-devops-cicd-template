import pytest
from app.main import app

@pytest.fixture
def client():
    app.config['TESTING'] = True
    with app.test_client() as client: yield client

def test_health(client):
    assert client.get('/health').status_code == 200
def test_get_users(client):
    assert 'users' in client.get('/api/users').get_json()
def test_create_user_success(client):
    assert client.post('/api/users', json={"name": "DevOps"}).status_code == 201
def test_create_user_fail(client):
    assert client.post('/api/users', json={}).status_code == 400
def test_get_user_not_found(client):
    assert client.get('/api/users/999').status_code == 404