#!/bin/bash
LOG_FILE="server_diag.log"
EXIT_CODE=0
log() { echo -e "$1"; echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$LOG_FILE"; }

if [[ "$1" == "--help" ]]; then
    echo "Usage: ./server-info.sh [URL...]"; exit 0
fi

log "=== Server Diagnostics ==="
log "Hostname: $(hostname)"
log "OS: $(uname -s)"
log "Uptime: $(uptime -p)"
log "CPU: $(nproc) cores"
log "RAM: $(free -h | awk '/Mem:/ {print $3 "/" $2}')"

if command -v docker &> /dev/null; then
    log "\n=== Docker ===\n$(docker ps --format 'table {{.ID}}\t{{.Image}}\t{{.Status}}')"
fi

for url in "$@"; do
    if curl -s -f "$url" > /dev/null; then
        log "[OK] $url"
    else
        log "[FAIL] $url"; EXIT_CODE=1
    fi
done
exit $EXIT_CODE